int intSize();
int doubleSize();
int pointerSize();
int changeValue();
int withinSameBlock(int *, int *);
int withinArray(int *, int, int *);
int invert(int, int, int);
