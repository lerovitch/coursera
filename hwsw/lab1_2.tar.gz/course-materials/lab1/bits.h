// Rating: 1
int bitAnd(int, int);
int test_bitAnd(int, int);
int bitXor(int, int);
int test_bitXor(int, int);
int thirdBits();
int test_thirdBits();
// Rating: 2
int fitsBits(int, int);
int test_fitsBits(int, int);
int sign(int);
int test_sign(int);
int getByte(int, int);
int test_getByte(int, int);
// Rating: 3
int logicalShift(int, int);
int test_logicalShift(int, int);
int addOK(int, int);
int test_addOK(int, int);
// Rating: 4
int bang(int);
int test_bang(int);
// Extra Credit: Rating: 3
int conditional(int, int, int);
int test_conditional(int, int, int);
// Extra Credit: Rating: 4
int isPower2(int);
int test_isPower2(int);
